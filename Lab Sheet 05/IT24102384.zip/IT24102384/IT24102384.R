setwd("C:\\Users\\User\\Desktop\\IT24102384")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")
fix(Delivery_Times)
attach(Delivery_Times)

hist(Delivery_Times$Delivery_Time_.minutes.,
     main = "Histogram of Delivery Time(miniutes)",
     xlab = "Delivery Time(miniutes)",
     ylab = "Frequency",
     breaks = seq(20,70,length = 10),
     right = FALSE,
     col = "lightblue")
delivery_hist<-hist(Delivery_Time_.minutes.,
                    breaks = seq(20,70,length.out = 10),
                    right = FALSE,
                    plot = FALSE)

breaks <- delivery_hist$breaks
freq <- delivery_hist$counts

cum_freq <-cumsum(freq)

cum_freq_with_zero <- c(0, cum_freq)

plot(breaks, cum_freq_with_zero,
     type = 'o',
     main = "Cumulative Frequency Polygon (Ogive) for Delivery times",
     xlab = "Delivery Time(miniutes)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum_freq)),
     col = "red",
     lwd = 2)

points(breaks, cum_freq_with_zero,
       pch = 16,
       col = "blue")
