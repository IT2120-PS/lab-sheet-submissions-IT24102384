getwd()
setwd("C:\\Users\\it24102384\\Desktop\\IT24102384")
data<-read.table("Data 4.txt", header=TRUE, sep =" ")
fix(data)
attach(data)

boxplot(X1,main="Box plot for Team Attendence", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary", outline=TRUE, outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

fivenum(Advertising_X2)
IQR(Advertsing_X2)

get_outliers<-function(z)
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5*iqr
  lb <- q1-1.5*iqr
  
  print(paste("Upper bound= ", ub))
  print(paste("Lower bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z<lb | z > ub], collapse= " "])))

#Branch - categorical, Nominal
#Sales_x1 - Numeric, Ratio
#Advertising_X2 = Numeric, Ratio
#Years_X3 - Numeric

q1 - 1.5 * iqr       
  upper <- q3 + 1.5 * iqr
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliers(branch_data$years)
fivenum(branch_data$advertising_)
IQR(branch_data$advertising)

find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)      
  q3 <- quantile(x, 0.75)     
  iqr <- q3 - q1                
  lower <- 
